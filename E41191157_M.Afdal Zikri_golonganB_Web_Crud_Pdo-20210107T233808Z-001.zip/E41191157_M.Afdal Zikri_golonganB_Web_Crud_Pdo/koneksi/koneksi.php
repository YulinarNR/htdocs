<?php

$konek = new PDO('mysql:host=localhost; dbname=pdo', 'root', '');