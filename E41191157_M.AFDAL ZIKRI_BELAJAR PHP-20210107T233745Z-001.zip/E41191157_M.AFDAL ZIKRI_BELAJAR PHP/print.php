<?php
print "<h2>Belajar PHP dari Nol!</h2>";
print "Hello World!<br>";
print "Belajar Mencetak teks di PHP!";
?>