<!DOCTYPE html>
<html>
<head>
    <title><? echo"Belajar PHP" ?></title>
</head>
<body>
    <?php
    echo "saya sedang belajar PHP<br>";
    echo "<p>Belajar PHP hingga jadi masster</p>";
    ?>
</body>
</html>