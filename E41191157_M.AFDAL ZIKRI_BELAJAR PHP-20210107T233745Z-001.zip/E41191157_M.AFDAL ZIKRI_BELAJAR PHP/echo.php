<?php
echo "<h2>Belajar PHP itu mudah</h2>";
echo("Hello Word!<br>");
echo "Aku Sedang Belajar PHP!<br>";
echo "Ini","teks","yang","dibuat","terpisah.";
?>