<?php

//membuat variabel baru
$nama_barang = "Minyak Goreng";
$harga = 15000;

//menampilkan isi variabel

echo "ibu membeli $nama_barang seharga Rp $harga";
?>