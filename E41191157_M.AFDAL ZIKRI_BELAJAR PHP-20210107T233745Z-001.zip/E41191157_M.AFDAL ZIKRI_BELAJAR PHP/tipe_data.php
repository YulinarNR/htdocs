<?php
 
 //tipe data char (karakter)
 $jenis_kelamin = 'L';

 //tipe data string (teks)
 $nama_lengkap = "Petani kode";

 //tipe data integer
 $umur = 20;

 //tipe data float
 $berat = 48.3;

 //tipe data float
 $tinggi = 182.2;

 //tipe data boolean
 $menikah = false;
 
 echo "Nama: $nama_lengkap<br>";
 echo "Jenis Kelamin: $jenis_kelamin<br>";
 echo "umur: $umur tahun<br>";
 echo "Berat Badan: $berat kg<br>";
 echo "Tinggi badan: $tinggi cm<br>";
 echo "Menikah: $menikah";
 ?>