<?php

echo "<html>";
echo "<head>";
echo "<tittle>Judul Web</tittle>";
echo "</head>";
echo "<body>";
echo "<h1>Selamat Datang</h1>";
echo "</body>";
echo "</html>";
?>